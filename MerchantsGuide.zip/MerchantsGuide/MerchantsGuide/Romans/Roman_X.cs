﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MerchantsGuide.Romans
{
    class Roman_X : Roman
    {
        public Roman_X()
        {
            Symbol = "X";
            Value = 10;
            RepeatedTimes = 3;
            Subtracted = "L,C";
        }
    }
}
