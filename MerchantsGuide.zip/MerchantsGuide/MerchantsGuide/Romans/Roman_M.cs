﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MerchantsGuide.Romans
{
    class Roman_M : Roman
    {
        public Roman_M()
        {
            Symbol = "M";
            Value = 1000;
            RepeatedTimes = 3;
            Subtracted = string.Empty;
        }
    }
}
