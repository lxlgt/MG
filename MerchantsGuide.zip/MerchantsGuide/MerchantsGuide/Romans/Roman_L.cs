﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MerchantsGuide.Romans
{
    class Roman_L : Roman
    {
        public Roman_L()
        {
            Symbol = "L";
            Value = 50;
            RepeatedTimes = 1;
            Subtracted = string.Empty;
        }
    }
}
