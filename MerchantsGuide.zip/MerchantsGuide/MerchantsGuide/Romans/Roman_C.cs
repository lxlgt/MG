﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MerchantsGuide.Romans
{
    class Roman_C : Roman
    {
        public Roman_C()
        {
            Symbol = "C";
            Value = 100;
            RepeatedTimes = 3;
            Subtracted = "D,M";
        }
    }
}
