﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MerchantsGuide.Romans
{
    class Roman_I : Roman
    {
        public Roman_I()
        {
            Symbol = "I";
            Value = 1;
            RepeatedTimes = 3;
            Subtracted = "V,X";
        }
    }
}
