﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MerchantsGuide.Romans
{
    public class Roman
    {
        protected int Value = 0;
        protected string Symbol = string.Empty;
        protected int RepeatedTimes = 0;
        protected string Subtracted = string.Empty;

        public static Roman Is(string symbol)
        {
            var roman = new Roman();
            switch (symbol)
            {
                case "I":
                    roman = new Roman_I();
                    break;
                case "V":
                    roman = new Roman_V();
                    break;
                case "X":
                    roman = new Roman_X();
                    break;
                case "L":
                    roman = new Roman_L();
                    break;
                case "C":
                    roman = new Roman_C();
                    break;
                case "D":
                    roman = new Roman_D();
                    break;
                case "M":
                    roman = new Roman_M();
                    break;
                default:
                    break;
            }
            return roman;
        }

        public static int Calculate(string RomanString)
        {
            var repeatTime = 1;
            var res = 0;
            var letters = RomanString;
            if (letters.Length > 0)
            {
                if (letters.Length == 1)
                {
                    res = Roman.Is(letters).Value;
                }
                else
                {
                    for (int i = 1; i < letters.Length; i++)
                    {
                        var pre = Roman.Is(letters[i - 1].ToString());
                        var cur = Roman.Is(letters[i].ToString());
                        if (pre.Value > cur.Value)
                        {
                            repeatTime = 1;
                            res += pre.Value;
                        }
                        else if (pre.Value == cur.Value)
                        {
                            repeatTime++;
                            if (cur.RepeatedTimes >= repeatTime)
                            {
                                res += pre.Value;
                            }
                            else
                            {
                                throw (new Exception("Exceed repeated times"));
                            }
                        }
                        else
                        {
                            repeatTime = 1;
                            if (pre.Subtracted.Contains(cur.Symbol))
                            {
                                res -= pre.Value;
                            }
                            else
                            {
                                throw (new Exception("Cannot subtract"));
                            }
                        }
                    }
                    res += Roman.Is(letters[letters.Length - 1].ToString()).Value;
                }
            }
            return res;
        }


    }
}
