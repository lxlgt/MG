﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MerchantsGuide.Romans
{
    class Roman_V : Roman
    {
        public Roman_V()
        {
            Symbol = "V";
            Value = 5;
            RepeatedTimes = 1;
            Subtracted = string.Empty;
        }
    }
}
