﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MerchantsGuide.Romans;

namespace MerchantsGuide
{
    class Parser
    {
        public string[] Parse(string[] lines)
        {
            var outputs = new List<string>();
            foreach (var line in lines)
            {
                if (line.Contains(" is "))
                {
                    if (line.Contains("?"))
                    {
                        outputs.Add(ParseQuestion(line));
                    }
                    else
                    {
                        ParseStatement(line);
                    }
                }
                else if(line != string.Empty)
                {
                    outputs.Add("I have no idea what you are talking about");
                }
            }
            return outputs.ToArray();
        }

        public void ParseStatement(string line)
        {
            try
            {
                if (line.Contains("Credits"))
                {
                    var eles = line.Split(new string[] { " is " }, StringSplitOptions.RemoveEmptyEntries);
                    var lefts = eles.First().Split(' ');
                    var romanString = string.Join(" ", lefts.Take(lefts.Length - 1));
                    var romanNum = ParseRomanNum(romanString);

                    var rights = eles.Last().Split(' ');
                    var totalNum = int.Parse(rights.First());
                    var unitNum = (double)totalNum / (double)romanNum;

                    Context.AddUnit(lefts.Last(), unitNum);
                }
                else
                {
                    var eles = line.Split(' ');
                    Context.AddParameter(eles.First(), eles.Last());
                }
            }
            catch (Exception ex)
            {

            }
        }

        public string ParseQuestion(string line)
        {
            try
            {
                var right = line.Split(new string[] { " is " }, StringSplitOptions.RemoveEmptyEntries).Last().TrimEnd(new char[] { ' ', '?' });
                var sb = new StringBuilder();
                sb.Append(right);
                sb.Append(" is ");

                if (line.Contains("much"))
                {
                    sb.Append(ParseRomanNum(right));
                }
                else
                {
                    sb.Append(ParseRomanNumWithUnit(right));
                    sb.Append(" Credits");
                }
                return sb.ToString();
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private int ParseRomanNumWithUnit(string line)
        {
            var eles = line.Split(' ');
            var unit = Context.GetUnit(eles.Last());
            var romanNum = ParseRomanNum(string.Join(" ", eles.Take(eles.Length - 1)));
            return (int)(unit * romanNum);
        }

        private int ParseRomanNum(string line)
        {
            var sb = new StringBuilder();
            foreach (var roman in line.Split(' '))
            {
                sb.Append(Context.GetParameter(roman));
            }
            return Roman.Calculate(sb.ToString());
        }
    }
}
