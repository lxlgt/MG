﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MerchantsGuide
{
    class Context
    {
        private static Dictionary<string, string> IntGalaNumDict = new Dictionary<string, string>();
        private static Dictionary<string, double> IntGalaUnitDict = new Dictionary<string, double>();

        public static void AddParameter(string key, string value)
        {
            IntGalaNumDict[key] = value;
        }

        public static string GetParameter(string key)
        {
            if (IntGalaNumDict.Keys.Contains(key))
            {
                return IntGalaNumDict[key];
            }
            else
            {
                throw (new Exception("I have no idea what you are talking about"));
            }
        }

        public static void AddUnit(string key, double value)
        {
            IntGalaUnitDict[key] = value;
        }

        public static double GetUnit(string key)
        {
            if (IntGalaUnitDict.Keys.Contains(key))
            {
                return IntGalaUnitDict[key];
            }
            else
            {
                throw (new Exception("I have no idea what you are talking about"));
            }
        }
    }
}
