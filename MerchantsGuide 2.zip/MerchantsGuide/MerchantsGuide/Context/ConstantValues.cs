﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MerchantsGuide.Context
{
    class ConstantValues
    {
        public static string QUESTION_MARK = " ?";
        public static string IS = " is ";
        public static char SPACE = ' ';
        public static string HOW_MANY = "how many";
        public static string HOW_MUCH = "how much";
        public static string CREDITS = " Credits";
        public static string ERROR_MESSAGE = "I have no idea what you are talking about";
    }
}
