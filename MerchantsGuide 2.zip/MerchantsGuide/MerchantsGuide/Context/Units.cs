﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MerchantsGuide.Context
{
    class Units
    {
        private Dictionary<string, double> UnitList = new Dictionary<string, double>();
        public void Add(string Unit, double Value)
        {
            UnitList[Unit] = Value;
        }
        public double Get(string Unit)
        {
            if (UnitList.Keys.Contains(Unit))
            {
                return UnitList[Unit];
            }
            throw (new Exception(ConstantValues.ERROR_MESSAGE));
        }
    }
}
