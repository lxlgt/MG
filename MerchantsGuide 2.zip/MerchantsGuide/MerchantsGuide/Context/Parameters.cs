﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MerchantsGuide.Context
{
    class Parameters
    {
        private Dictionary<string, string> RomanList = new Dictionary<string, string>();
        public void Add(string Alias, string Roman)
        {
            RomanList[Alias] = Roman;
        }
        public string Get(string Alias)
        {
            if(RomanList.Keys.Contains(Alias))
            {
                return RomanList[Alias];
            }
            throw (new Exception(ConstantValues.ERROR_MESSAGE));
        }
    }
}
