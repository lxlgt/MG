﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MerchantsGuide.Context;

namespace MerchantsGuide.Models
{
    class Parser
    {
        private Parameters parameters = new Parameters();
        private Units units = new Units();

        public string[] Parse(string[] inputs)
        {
            var outputs = new List<string>();
            foreach (var input in inputs)
            {
                if (!string.IsNullOrEmpty(input))
                {
                    if (input.Contains(ConstantValues.IS))
                    {
                        if (input.EndsWith(ConstantValues.QUESTION_MARK))
                        {
                            outputs.Add(ParseQuestion(input));
                        }
                        else
                        {
                            ParseStatement(input);
                        }
                    }
                    else
                    {
                        outputs.Add(ConstantValues.ERROR_MESSAGE);
                    }
                }
            }
            return outputs.ToArray();
        }

        public void ParseStatement(string statement)
        {
            try
            {                
                if (statement.EndsWith(ConstantValues.CREDITS))
                {
                    var elements = statement.Split(new string[] { ConstantValues.IS }, StringSplitOptions.RemoveEmptyEntries);
                    var lefts = elements.First().Split(ConstantValues.SPACE);
                    var aliasString = string.Join(ConstantValues.SPACE.ToString(), lefts.Take(lefts.Length - 1));
                    var romanNum = ParseAliasString(aliasString);

                    var rights = elements.Last().Split(ConstantValues.SPACE);
                    var totalNum = int.Parse(rights.First());
                    var unitNum = (double)totalNum / (double)romanNum;

                    units.Add(lefts.Last(), unitNum);
                }
                else
                {
                    var elements = statement.Split(ConstantValues.SPACE);
                    parameters.Add(elements.First(), elements.Last());
                }
            }
            catch (Exception ex)
            {

            }
        }

        public string ParseQuestion(string question)
        {
            try
            {
                var body = question.Replace(ConstantValues.QUESTION_MARK, string.Empty).Split(new string[] { ConstantValues.IS }, StringSplitOptions.RemoveEmptyEntries).Last();
                var resultBuilder = new StringBuilder();
                resultBuilder.Append(body);
                resultBuilder.Append(ConstantValues.IS);

                if (question.StartsWith(ConstantValues.HOW_MUCH))
                {
                    resultBuilder.Append(ParseAliasString(body));
                }
                else
                {
                    resultBuilder.Append(ParseRomanNumWithUnit(body));
                    resultBuilder.Append(ConstantValues.CREDITS);
                }
                
                return resultBuilder.ToString();
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private int ParseRomanNumWithUnit(string line)
        {
            var eles = line.Split(ConstantValues.SPACE);
            var unit = units.Get(eles.Last());
            var romanNum = ParseAliasString(string.Join(ConstantValues.SPACE.ToString(), eles.Take(eles.Length - 1)));
            return (int)(unit * romanNum);
        }

        private int ParseAliasString(string aliasString)
        {
            var romanString = new StringBuilder();
            foreach (var alias in aliasString.Split(ConstantValues.SPACE))
            {
                romanString.Append(parameters.Get(alias));
            }
            return RomanNumber.Calculate(romanString.ToString());
        }

    }
}
