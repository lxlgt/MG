﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MerchantsGuide.Models
{
    class RomanNumber
    {
        public int Value { get; set; }
        public string Symbol { get; set; }
        public int RepeateLimit { get; set; }
        public string CanSubtractedFrom { get; set; }

        public RomanNumber(string symbol, int value, int repeatLimit, string canSubtractedFrom)
        {
            Value = value;
            Symbol = symbol;
            RepeateLimit = repeatLimit;
            CanSubtractedFrom = canSubtractedFrom;
        }

        public static RomanNumber Roman(string symbol)
        {
            switch (symbol)
            {
                case "I":
                    return new RomanNumber("I", 1, 3, "VX");
                case "V":
                    return new RomanNumber("V", 5, 1, "");
                case "X":
                    return new RomanNumber("X", 10, 3, "LC");
                case "L":
                    return new RomanNumber("L", 50, 1, "");
                case "C":
                    return new RomanNumber("C", 100, 3, "DM");
                case "D":
                    return new RomanNumber("D", 500, 1, "");
                case "M":
                    return new RomanNumber("M", 1000, 3, "");
                default:
                    return null;
            }
        }

        public static int Calculate(string RomanString)
        {
            var repeatTime = 1;
            var result = 0;
            var letters = RomanString;
            if (letters.Length > 0)
            {
                if (letters.Length == 1)
                {
                    result = Roman(letters).Value;
                }
                else
                {
                    for (int i = 1; i < letters.Length; i++)
                    {
                        var pre = Roman(letters[i - 1].ToString());
                        var cur = Roman(letters[i].ToString());
                        if (pre.Value > cur.Value)
                        {
                            repeatTime = 1;
                            result += pre.Value;
                        }
                        else if (pre.Value == cur.Value)
                        {
                            repeatTime++;
                            if (cur.RepeateLimit >= repeatTime)
                            {
                                result += pre.Value;
                            }
                            else
                            {
                                throw (new Exception("Exceed repeated times"));
                            }
                        }
                        else
                        {
                            repeatTime = 1;
                            if (pre.CanSubtractedFrom.Contains(cur.Symbol))
                            {
                                result -= pre.Value;
                            }
                            else
                            {
                                throw (new Exception("Cannot subtract"));
                            }
                        }
                    }
                    result += Roman(letters[letters.Length - 1].ToString()).Value;
                }
            }
            return result;
        }

    }
}
