﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MerchantsGuide.Models
{
    class FileIO
    {
        public static string[] ReadInput(string path)
        {
            if (File.Exists(path))
            {
                return File.ReadAllLines(path);
            }
            return new string[] { string.Empty };
        }

        public static void WriteOutput(string path, string[] contents)
        {
            File.WriteAllLines(path, contents);
        }
    }
}
