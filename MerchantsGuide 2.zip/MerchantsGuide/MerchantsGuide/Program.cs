﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MerchantsGuide.Models;

namespace MerchantsGuide
{
    class Program
    {
        static void Main(string[] args)
        {
            var parser = new Parser();
            var inputs = FileIO.ReadInput("Input.txt");
            var outputs = parser.Parse(inputs);
            FileIO.WriteOutput("Output.txt", outputs);
        }

    }
}
